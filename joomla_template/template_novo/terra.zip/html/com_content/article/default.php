<?php
/**
 * @package     Cleanportal_2019
 * @subpackage  tpl_cleanportal_2019
 *
 * @author      Charles Guedes <charlesgcf@gmail.com>
 * @copyright   Copyright (C) 2019 Capgemini do Brasil. All rights reserved.
 * @license     Commercial License
 */

// No direct access.
defined('_JEXEC') or die;

// Helper do template usado no final do layout (tags/metakeys)
require_once __DIR__ . '/_helper.php';

// Include the component helpers.
JHtml::addIncludePath(JPATH_COMPONENT . '/helpers');

// Create shortcuts to some parameters.
$params  = $this->item->params;
$images  = json_decode($this->item->images);
$urls    = json_decode($this->item->urls);
$canEdit = $params->get('access-edit');
$user    = JFactory::getUser();
$info    = $params->get('info_block_position', 0);

// Load the caption behavior script.
JHtml::_('behavior.caption');

$useDefList = ($params->get('show_modify_date') || $params->get('show_publish_date') || $params->get('show_create_date') || $params->get('show_hits') || $params->get('show_category') || $params->get('show_parent_category') || $params->get('show_author'));
?>
<div class="single-page item-page<?php echo $this->pageclass_sfx; ?>">
	<div class="page-header">
		<?php if (!$useDefList && $this->print): ?>
			<div id="pop-print" class="btn pull-right">
				<?php echo JHtml::_('icon.print_screen', $this->item, $params); ?>
			</div>
		<?php endif; ?>
		<?php if (!$this->print): ?>
			<?php if ($canEdit || $params->get('show_print_icon') || $params->get('show_email_icon')): ?>
				<ul class="list-unstyled list-inline pull-right actions">
					<?php if ($params->get('show_print_icon')): ?>
						<li class="print-icon"><?php echo JHtml::_('icon.print_popup', $this->item, $params); ?></li>
					<?php endif; ?>
					<?php if ($params->get('show_email_icon')): ?>
						<li class="email-icon"><?php echo JHtml::_('icon.email', $this->item, $params); ?></li>
					<?php endif; ?>
					<?php if ($canEdit): ?>
						<li class="edit-icon"><?php echo JHtml::_('icon.edit', $this->item, $params); ?></li>
					<?php endif; ?>
				</ul>
			<?php endif; ?>
		<?php else: ?>
			<?php if ($useDefList): ?>
				<ul class="list-unstyled list-inline pull-right actions">
					<li class="print-icon"><?php echo JHtml::_('icon.print_screen', $this->item, $params); ?></li>
				</ul>
			<?php endif; ?>
		<?php endif; ?>
		<h2>
			<?php if ($this->params->get('show_page_heading', 1)): ?>
				<?php echo $this->escape($this->params->get('page_heading')); ?>
				<?php if ($params->get('show_title') || $params->get('show_author')): ?>
					/
					<?php if ($this->item->state == 0): ?>
						<span class="label label-warning"><?php echo JText::_('JUNPUBLISHED'); ?></span>
					<?php endif; ?>
					<?php if ($params->get('show_title')): ?>
						<?php if ($params->get('link_titles') && !empty($this->item->readmore_link)): ?>
							<a href="<?php echo $this->item->readmore_link; ?>"><?php echo $this->escape($this->item->title); ?></a>
						<?php else: ?>
							<?php echo $this->escape($this->item->title); ?>
						<?php endif; ?>
					<?php endif; ?>
				<?php endif; ?>
			<?php else: ?>
				<?php if ($params->get('show_title') || $params->get('show_author')): ?>
					<?php if ($this->item->state == 0): ?>
						<span class="label label-warning"><?php echo JText::_('JUNPUBLISHED'); ?></span>
					<?php endif; ?>
					<?php if ($params->get('show_title')): ?>
						<?php if ($params->get('link_titles') && !empty($this->item->readmore_link)): ?>
							<a href="<?php echo $this->item->readmore_link; ?>"><?php echo $this->escape($this->item->title); ?></a>
						<?php else: ?>
							<?php echo $this->escape($this->item->title); ?>
						<?php endif; ?>
					<?php endif; ?>
				<?php endif; ?>
			<?php endif; ?>
		</h2>
	</div>

	<?php if (!empty($this->item->pagination) && $this->item->pagination && !$this->item->paginationposition && $this->item->paginationrelative): ?>
		<?php echo $this->item->pagination; ?>
	<?php endif; ?>

	<?php if ($useDefList && ($info == 0 || $info == 2)): ?>
		<div class="article-info muted">
			<dl class="article-info">
				<!-- <dt class="article-info-term"><?php //echo JText::_('COM_CONTENT_ARTICLE_INFO'); ?></dt> -->
				<?php if ($params->get('show_author') && !empty($this->item->author )): ?>
					<dd class="createdby">
						<?php $author = $this->item->created_by_alias ? $this->item->created_by_alias : $this->item->author; ?>
						<?php if (!empty($this->item->contactid) && $params->get('link_author') == true): ?>
							<?php
							$needle = 'index.php?option=com_contact&view=contact&id=' . $this->item->contactid;
							$menu = JFactory::getApplication()->getMenu();
							$item = $menu->getItems('link', $needle, true);
							$cntlink = !empty($item) ? $needle . '&Itemid=' . $item->id : $needle;
							?>
							<?php echo JText::sprintf('COM_CONTENT_WRITTEN_BY', JHtml::_('link', JRoute::_($cntlink), $author)); ?>
						<?php else: ?>
							<?php echo JText::sprintf('COM_CONTENT_WRITTEN_BY', $author); ?>
						<?php endif; ?>
					</dd>
				<?php endif; ?>
				<?php if ($params->get('show_parent_category') && !empty($this->item->parent_slug)): ?>
					<dd class="parent-category-name">
						<?php $title = $this->escape($this->item->parent_title);
						$url = '<a href="' . JRoute::_(ContentHelperRoute::getCategoryRoute($this->item->parent_slug)) . '">' . $title . '</a>';?>
						<?php if ($params->get('link_parent_category') && !empty($this->item->parent_slug)): ?>
							<?php echo JText::sprintf('COM_CONTENT_PARENT', $url); ?>
						<?php else: ?>
							<?php echo JText::sprintf('COM_CONTENT_PARENT', $title); ?>
						<?php endif; ?>
					</dd>
				<?php endif; ?>
				<?php if ($params->get('show_category')): ?>
					<dd class="category-name">
						<?php $title = $this->escape($this->item->category_title);
						$url = '<a href="' . JRoute::_(ContentHelperRoute::getCategoryRoute($this->item->catslug)) . '">' . $title . '</a>';?>
						<?php if ($params->get('link_category') && $this->item->catslug): ?>
							<?php echo JText::sprintf('COM_CONTENT_CATEGORY', $url); ?>
						<?php else: ?>
							<?php echo JText::sprintf('COM_CONTENT_CATEGORY', $title); ?>
						<?php endif; ?>
					</dd>
				<?php endif; ?>
				<?php if ($params->get('show_publish_date')): ?>
					<dd class="published">
						<!-- <span class="icon-calendar"></span>  -->
						<?php echo JText::sprintf('COM_CONTENT_PUBLISHED_DATE_ON', JHtml::_('date', $this->item->publish_up, JText::_('DATE_FORMAT_LC3'))); ?>
					</dd>
				<?php endif; ?>
				<?php if ($info == 0): ?>
					<?php if ($params->get('show_modify_date')): ?>
						<dd class="modified">
							<!-- <span class="icon-calendar"></span>  -->
							<?php echo JText::sprintf('COM_CONTENT_LAST_UPDATED', JHtml::_('date', $this->item->modified, JText::_('DATE_FORMAT_LC3'))); ?>
						</dd>
					<?php endif; ?>
					<?php if ($params->get('show_create_date')): ?>
						<dd class="create">
							<!-- <span class="icon-calendar"></span>  -->
							<?php echo JText::sprintf('COM_CONTENT_CREATED_DATE_ON', JHtml::_('date', $this->item->created, JText::_('DATE_FORMAT_LC3'))); ?>
						</dd>
					<?php endif; ?>
					<?php if ($params->get('show_hits')): ?>
						<dd class="hits">
							<span class="icon-eye-open"></span> <?php echo JText::sprintf('COM_CONTENT_ARTICLE_HITS', $this->item->hits); ?>
						</dd>
					<?php endif; ?>
				<?php endif; ?>
			</dl>
		</div>
	<?php endif; ?>
	
	<?php if (!$params->get('show_intro')): ?>
		<?php echo $this->item->event->afterDisplayTitle; ?>
	<?php endif; ?>
	<?php echo $this->item->event->beforeDisplayContent; ?>
	<?php if (isset($urls) && ((!empty($urls->urls_position) && ($urls->urls_position == '0')) || ($params->get('urls_position') == '0' && empty($urls->urls_position))) || (empty($urls->urls_position) && (!$params->get('urls_position')))): ?>
		<?php echo $this->loadTemplate('links'); ?>
	<?php endif; ?>
	<?php if ($params->get('access-view')): ?>
		<?php if (isset($images->image_fulltext) && !empty($images->image_fulltext)): ?>
		<?php $imgfloat = (empty($images->float_fulltext)) ? $params->get('float_fulltext'): $images->float_fulltext; ?>
		<div class="pull-<?php echo htmlspecialchars($imgfloat); ?> item-image">
			<img <?php if ($images->image_fulltext_caption): echo 'class="caption"' . ' title="' . htmlspecialchars($images->image_fulltext_caption) . '"'; endif; ?> src="<?php echo htmlspecialchars($images->image_fulltext); ?>" alt="<?php echo htmlspecialchars($images->image_fulltext_alt); ?>"/>
		</div>
	<?php endif; ?>
	<?php if (!empty($this->item->pagination) && $this->item->pagination && !$this->item->paginationposition && !$this->item->paginationrelative): ?>
		<?php echo $this->item->pagination; ?>
	<?php endif; ?>
	<?php if (isset ($this->item->toc)): ?>
		<?php echo $this->item->toc; ?>
	<?php endif; ?>
	<?php echo $this->item->text; ?>
	<?php if ($useDefList && ($info == 1 || $info == 2)): ?>
		<div class="article-info muted">
			<dl class="article-info">
				<dt class="article-info-term"><?php echo JText::_('COM_CONTENT_ARTICLE_INFO'); ?></dt>
				<?php if ($info == 1): ?>
					<?php if ($params->get('show_author') && !empty($this->item->author )): ?>
						<dd class="createdby">
							<?php $author = $this->item->created_by_alias ? $this->item->created_by_alias : $this->item->author; ?>
							<?php if (!empty($this->item->contactid) && $params->get('link_author') == true): ?>
							<?php
							$needle = 'index.php?option=com_contact&view=contact&id=' . $this->item->contactid;
							$menu = JFactory::getApplication()->getMenu();
							$item = $menu->getItems('link', $needle, true);
							$cntlink = !empty($item) ? $needle . '&Itemid=' . $item->id : $needle;
							?>
							<?php echo JText::sprintf('COM_CONTENT_WRITTEN_BY', JHtml::_('link', JRoute::_($cntlink), $author)); ?>
							<?php else: ?>
							<?php echo JText::sprintf('COM_CONTENT_WRITTEN_BY', $author); ?>
							<?php endif; ?>
						</dd>
					<?php endif; ?>
					<?php if ($params->get('show_parent_category') && !empty($this->item->parent_slug)): ?>
						<dd class="parent-category-name">
							<?php $title = $this->escape($this->item->parent_title);
							$url = '<a href="' . JRoute::_(ContentHelperRoute::getCategoryRoute($this->item->parent_slug)) . '">' . $title . '</a>';?>
							<?php if ($params->get('link_parent_category') && $this->item->parent_slug): ?>
								<?php echo JText::sprintf('COM_CONTENT_PARENT', $url); ?>
							<?php else: ?>
								<?php echo JText::sprintf('COM_CONTENT_PARENT', $title); ?>
							<?php endif; ?>
						</dd>
					<?php endif; ?>
					<?php if ($params->get('show_category')): ?>
						<dd class="category-name">
							<?php $title = $this->escape($this->item->category_title);
							$url = '<a href="' . JRoute::_(ContentHelperRoute::getCategoryRoute($this->item->catslug)) . '">' . $title . '</a>';?>
							<?php if ($params->get('link_category') && $this->item->catslug): ?>
								<?php echo JText::sprintf('COM_CONTENT_CATEGORY', $url); ?>
							<?php else: ?>
								<?php echo JText::sprintf('COM_CONTENT_CATEGORY', $title); ?>
							<?php endif; ?>
						</dd>
					<?php endif; ?>
					<?php if ($params->get('show_publish_date')): ?>
						<dd class="published">
							<span class="icon-calendar"></span>
							<?php echo JText::sprintf('COM_CONTENT_PUBLISHED_DATE_ON', JHtml::_('date', $this->item->publish_up, JText::_('DATE_FORMAT_LC3'))); ?>
						</dd>
					<?php endif; ?>
				<?php endif; ?>
				<?php if ($params->get('show_create_date')): ?>
					<dd class="create">
						<span class="icon-calendar"></span>
						<?php echo JText::sprintf('COM_CONTENT_CREATED_DATE_ON', JHtml::_('date', $this->item->created, JText::_('DATE_FORMAT_LC3'))); ?>
					</dd>
				<?php endif; ?>
				<?php if ($params->get('show_modify_date')): ?>
					<dd class="modified">
						<span class="icon-calendar"></span>
						<?php echo JText::sprintf('COM_CONTENT_LAST_UPDATED', JHtml::_('date', $this->item->modified, JText::_('DATE_FORMAT_LC3'))); ?>
					</dd>
				<?php endif; ?>
				<?php if ($params->get('show_hits')): ?>
					<dd class="hits">
						<span class="icon-eye-open"></span> <?php echo JText::sprintf('COM_CONTENT_ARTICLE_HITS', $this->item->hits); ?>
					</dd>
				<?php endif; ?>
			</dl>
		</div>
	<?php endif; ?>
	<?php if (!empty($this->item->pagination) && $this->item->pagination && $this->item->paginationposition && !$this->item->paginationrelative): ?>
		<?php echo $this->item->pagination; ?>
	<?php endif; ?>
	<?php if (isset($urls) && ((!empty($urls->urls_position) && ($urls->urls_position == '1')) || ($params->get('urls_position') == '1'))): ?>
		<?php echo $this->loadTemplate('links'); ?>
	<?php endif; ?>
	<?php // Optional teaser intro text for guests ?>
	<?php elseif ($params->get('show_noauth') == true && $user->get('guest')): ?>
		<?php echo $this->item->introtext; ?>
		<?php // Optional link to let them register to see the whole article. ?>
		<?php if ($params->get('show_readmore') && $this->item->fulltext != null):
			$link1 = JRoute::_('index.php?option=com_users&view=login');
			$link = new JUri($link1);?>
				<p class="readmore">
					<a href="<?php echo $link; ?>">
						<?php $attribs = json_decode($this->item->attribs); ?>
						<?php
						if ($attribs->alternative_readmore == null):
							echo JText::_('COM_CONTENT_REGISTER_TO_READ_MORE');
						elseif ($readmore = $this->item->alternative_readmore):
							echo $readmore;
							if ($params->get('show_readmore_title', 0) != 0):
								echo JHtml::_('string.truncate', ($this->item->title), $params->get('readmore_limit'));
							endif;
						elseif ($params->get('show_readmore_title', 0) == 0):
							echo JText::sprintf('COM_CONTENT_READ_MORE_TITLE');
						else :
							echo JText::_('COM_CONTENT_READ_MORE');
							echo JHtml::_('string.truncate', ($this->item->title), $params->get('readmore_limit'));
						endif; ?>
					</a>
				</p>
		<?php endif; ?>
	<?php endif; ?>

<?php
$categories = TemplateContentArticleHelper::getParentCategoriesByRoute($this->item->parent_route);
$showBelowContent = TemplateContentArticleHelper::showBelowContent($categories, $this->item);
if (count($showBelowContent) > 0): ?>
	<?php if (in_array('metakeys', $showBelowContent)): ?>
	<div class="lista-tags">
		tags:
		<?php TemplateContentArticleHelper::displayMetakeyLinks( $this->item->metakey ); ?>		
	</div>
	<?php endif; ?>
<?php endif; ?>
	<?php if (!empty($this->item->pagination) && $this->item->pagination && $this->item->paginationposition && $this->item->paginationrelative): ?>
		<?php echo $this->item->pagination; ?>
	<?php endif; ?>
	<?php echo $this->item->event->afterDisplayContent; ?>
</div>

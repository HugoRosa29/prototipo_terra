<?php
/**
 * @package     Cleanportal_2019
 * @subpackage  tpl_cleanportal_2019
 *
 * @author      Charles Guedes <charlesgcf@gmail.com>
 * @copyright   Copyright (C) 2019 Capgemini do Brasil. All rights reserved.
 * @license     Commercial License
 */

// No direct access.
defined('_JEXEC') or die;

// Note. It is important to remove spaces between elements.
$class = $item->anchor_css ? 'class="' . $item->anchor_css . '" ' : 'class="link-megamenu-sub"';
$title = $item->anchor_title ? 'title="' . $item->anchor_title . '" ' : '';
$desc = "<br>";

if ($item->menu_image)
{
	$item->params->get('menu_text', 1) ?
	$linktype = '<img src="' . $item->menu_image . '" alt="' . $item->title . '" /><span class="image-title">' . $item->title . '</span> ' :
	$linktype = '<img src="' . $item->menu_image . '" alt="' . $item->title . '" />';
}
else
{
	$linktype = $item->title;
}
if(!empty($item->params->get('menu-meta_description'))){
	$desc = "<span class=\"desc-megamenu-sub\">".$item->params->get('menu-meta_description')."</span><br><br>";
	//$desc = $item->params->get('menu-meta_description');
}
if ($menu_icon = $item->params->get('menu_icon'))
{
	$linktype = '<i class="' . $menu_icon . '"></i> ' . $linktype;
}

switch ($item->browserNav):
	default:
	case 0:
?><a <?php echo $class; ?>href="<?php echo $item->flink; ?>" <?php echo $title; ?>><?php echo $linktype; ?></a><br><?php echo $desc;
		break;
	case 1:
		// _blank
?><a <?php echo $class; ?>href="<?php echo $item->flink; ?>" target="_blank" <?php echo $title; ?>><?php echo $linktype; ?></a><br><?php echo $desc;
		break;
	case 2:
	// window.open
?><a <?php echo $class; ?>href="<?php echo $item->flink; ?>" onclick="window.open(this.href,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes');return false;" <?php echo $title; ?>><?php echo $linktype; ?></a><br><?php echo $desc;?>
<?php
		break;
endswitch;
